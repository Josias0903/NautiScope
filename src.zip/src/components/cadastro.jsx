// import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
// import "../scriptCadastros.component"
// import './styles.css';

// // let button = document.getElementById("submit");

// // button.onclick = async function () {
// //     let nome = document.getElementById("nome").value;
// //     let email = document.getElementById("email").value;
// //     let senha = document.getElementById("senha").value;

// //     let dados = { nome, email, senha }
// //     console.log(dados);
// //     const response = await fetch("http://localhost:3006/api/register", {
// //         method: "POST",
// //         headers: {"Content-type":"application/json"},
// //         body: JSON.stringify(dados)
// //     })

// //     const results = await response.json();
// //     console.log(results);
// //     if(results.success){
// //         alert("Sucesso");
// //         window.location.href = "login.html";

// //     }else{
// //         alert("Não foi sucesso")
// //         console.log(content.sql);
// //     }

// // }

//   return (
//     <div className="auth-container">
//       <h2 className="auth-title">Cadastro</h2>
//       <form className="auth-form" onSubmit={handleSignIn}>
//         <input
//           type="text"
//           name="username"
//           placeholder="Username"
//           className="auth-input"
//           value={formData.username}
//           onChange={handleChange}
//           required
//         />
//         <input
//           type="email"
//           name="email"
//           placeholder="Email"
//           className="auth-input"
//           value={formData.email}
//           onChange={handleChange}
//           required
//         />
//         <input
//           type="password"
//           name="password"
//           placeholder="Password"
//           className="auth-input"
//           value={formData.password}
//           onChange={handleChange}
//           required
//         />
//         <button type="submit" className="auth-button">Cadastro</button>
//       </form>
//     </div>
//   );


// export default SignIn;
